
function validation(){
 var fname = document.validationform.AER_Name.value;
 var lname = document.validationform.lname.value;
 var password = document.validationform.password.value;
 var cpass = document.validationform.cpass.value;

 if (fname || lname != a-z){
     alert ("Name must be alphabet");
     return false;
 }
 else if(password.length <6){
     alert ("Password should be greater than 6");
 }
 else if (cpass != password){
     alert("Password should be similar")
 }

 
}